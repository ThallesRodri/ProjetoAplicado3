# Projeto Aplicado III – Recomendação de jogos na Steam

Universidade Presbiteriana Mackenzie – Curso Superior de Tecnologia em Banco de Dados
Equipe: Leandro Henrique Pereira, Murilo Freitas Rodrigues e Thalles Rodrigues.

Sistema de recomendação top-10 de jogos individuais a partir das avaliações positivas da coleção pública
*Steam Video Game and Bundle Data* (UCSD, versão 1 – comunidade australiana). Este README substitui o anterior,
que mencionava por engano "transações de vendas de café" e o título sobre vendas da BMW da etapa 1.

## Estrutura

```
dados/
  interacoes.csv.gz      base de trabalho pseudonimizada (user, item, positive, posted)
  titulos.csv            nomes históricos dos jogos (somente exibição)
  proveniencia.json      URLs oficiais, data de acesso e SHA-256 dos arquivos originais
scripts/
  preparar_dados.py      etapa 2: obtém os arquivos oficiais e gera a base de trabalho
  executar.py            etapa 2: prova de conceito (Popularidade x ItemKNN)
  recomendar.py          etapa 2: demonstração com o modelo da prova de conceito
etapa3/
  comum.py               carregamento auditado, partições, modelos e métricas
  reproduzir_e2.py       reprodução independente da etapa 2 (semente 42)
  etapa3.py              experimento completo da etapa 3 (protocolos A e B)
  figuras_exploratorias.py, figuras_resultados.py
  consolidar_modelo.py   ajusta e persiste o modelo escolhido; mede latência
  recomendar_etapa3.py   gera o top-10 de um usuário com o modelo persistido
resultados_etapa3/       saídas: grades de validação, métricas de teste, segmentos, resumo
figuras/                 figuras usadas no documento
```

## Reprodução

Todos os comandos devem ser executados **a partir da pasta raiz do pacote** (a que contém `dados/`, `scripts/` e
`etapa3/`). No Windows (PowerShell/Anaconda):

```powershell
cd C:\Users\<usuario>\...\Pacote_tecnico_Etapa_3
python scripts\executar.py                      # etapa 2 -> resultados_etapa2\ (NDCG@10 0,124555 / 0,119434)
python scripts\recomendar.py                    # demonstração da etapa 2
python etapa3\reproduzir_e2.py dados resultados_etapa3
python etapa3\etapa3.py dados resultados_etapa3            # ~1 h em 2 núcleos
python etapa3\figuras_exploratorias.py dados figuras
python etapa3\figuras_resultados.py resultados_etapa3 figuras
python etapa3\consolidar_modelo.py dados resultados_etapa3 modelo_final A
python etapa3\recomendar_etapa3.py modelo_final dados\titulos.csv
```

Todos os arquivos são lidos e gravados em UTF-8, de modo que os scripts funcionam no Windows (cuja codificação padrão
é cp1252). A base de trabalho já está em `dados/`; `scripts/preparar_dados.py` só baixa os arquivos originais da
UCSD se `dados/interacoes.csv.gz` não existir.

### Comandos equivalentes (Linux/macOS)


Requisitos: Python 3.12 ou superior, numpy, pandas, scipy e matplotlib (`pip install -r requirements.txt`).

```bash
# 1) (opcional) reconstruir a base a partir dos arquivos oficiais
python scripts/preparar_dados.py
# 2) reprodução da etapa 2 (deve repetir NDCG@10 = 0,124555 / 0,119434)
python etapa3/reproduzir_e2.py dados resultados_etapa3
# 3) experimento da etapa 3 (aprox. 1 h em 2 núcleos)
python etapa3/etapa3.py dados resultados_etapa3
python etapa3/figuras_exploratorias.py dados figuras
python etapa3/figuras_resultados.py resultados_etapa3 figuras
# 4) modelo final e demonstração
python etapa3/consolidar_modelo.py dados modelo_final
python etapa3/recomendar_etapa3.py modelo_final dados/titulos.csv
```

O SHA-256 de `dados/interacoes.csv.gz` deve ser
`49959f4c10de06ec090133e36024d00463f3d9f8ab8e2b624e827a7e5fc93f6c`.

## Protocolos

* **A – aleatório por usuário**: usuários com ≥ 5 positivos; 1 positivo de validação e 1 de teste; sementes
  42, 7, 13, 2024 e 2026. A semente 42 reproduz exatamente a etapa 2.
* **B – temporal global**: cortes nos quantis 80% e 90% das datas. Avaliações sem ano recebem o ano de 2016
  (hipótese H-T, testada no documento); a variante "somente datados" exclui esses registros.

Hiperparâmetros são escolhidos apenas na validação; o teste é avaliado uma única vez por configuração escolhida.

## Dados e licença

Os dados pertencem aos autores da coleção (McAuley, UCSD; Pathak, Gupta e McAuley, 2017) e são usados para fins
acadêmicos. Textos das avaliações e URLs de perfis não são armazenados; identificadores de usuários são
pseudonimizados por SHA-256.
